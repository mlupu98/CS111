#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <getopt.h>
#include <ctype.h>
#include <math.h>
#include <poll.h>
#include <signal.h>
#include <string.h>
#include <sys/types.h>
#include <sys/errno.h>
#include <sys/time.h>
#include <time.h>
#include <mraa.h>
#include <mraa/aio.h>

#define PERIOD 'd'
#define SCALE  's'
#define LOG    'l'

mraa_aio_context sensor;
mraa_gpio_context button;

struct pollfd polls[1];
struct timeval tv;
struct tm* currentTime;
struct timezone timeZone;
time_t periodEnd;
int samplesPerSecond = 1;
int logging = 0;
FILE* logFd = NULL;

//void buttonPressed()
//{
//
//}

int findCommand( const char* input, char* command, int periodFlag, int logFlag )
{
    int retVal = 1;

    if( logFlag == 1 )
    {
        int i = 0;
        for( ; i < 3; i++ )
        {
            if( input[i] != command[i] )
            {
                retVal = 0;
            }
        }

        if( retVal == 1)
        {
            logging = 1;
        }
    }
    else if( periodFlag == 1 )
    {
        int i = 0;
        if( strlen(input) >= 7)
        {
            for (; i < 7; i++) {
                if (input[i] != command[i]) {
                    retVal = 0;
                }
            }
        }
        else
        {
            retVal = 0;
        }

        if( retVal == 1 )
        {
            int newPeriod = 0;

            while (input[i] != '\n') {
                if (isdigit(input[i])) // do we need to take decimals?
                {
                    newPeriod *= 10;
                    newPeriod += input[i] - '0';
                    i++;
                } else {
                    fprintf(stderr, "Error: invalid period");
                    exit(1);
                }

            }

            samplesPerSecond = newPeriod;
        }

    }
    else if( strcmp( input, command ) != 0 ) // it is a command
    {
        retVal = 0;
    }

    return retVal;
}

void offHandler()
{
    gettimeofday(&tv, &timeZone);
    currentTime = localtime(&(tv.tv_sec));

    char outputBuffer[256];
    sprintf(outputBuffer, "%02d:%02d:%02d SHUTDOWN\n", currentTime->tm_hour, currentTime->tm_min, currentTime->tm_sec);

    if( logging == 1)
    {
        fputs( outputBuffer, logFd);
    }

    fputs(outputBuffer, stdout);

    exit(0);
}

void handleInput( const char* input, int* pauseReading, char* tempScale )
{
    if( findCommand(input, "START\n", 0, 0) == 1)
    {
        *pauseReading = 0;
        if( logging == 1 ) { fprintf(logFd, "%s\n", input); }
        fflush(logFd);
    }
    else if ( findCommand( input, "STOP\n", 0, 0) == 1)
    {
        *pauseReading = 1;
        if( logging == 1 ) { fprintf(logFd, "%s\n", input); }
        fflush(logFd);
    }
    else if ( findCommand( input, "SCALE=C\n", 0, 0) == 1)
    {
        *tempScale = 'C';
        if( logging == 1 ) { fprintf(logFd, "%s\n", input); }
        fflush(logFd);
    }
    else if ( findCommand( input, "SCALE=F\n", 0, 0) == 1)
    {
        *tempScale = 'F';
        if( logging == 1 ) { fprintf(logFd, "%s\n", input); }
        fflush(logFd);
    }
    else if ( findCommand( input, "LOG ", 0, 1) == 1)
    {
        if( logging == 1 ) { fprintf(logFd, "%s\n", input); } // double check this
        fflush(logFd);
    }
    else if ( findCommand( input, "PERIOD=", 1, 0) == 1)
    {
        if( logging == 1 ) { fprintf(logFd, "%s%d\n", input, samplesPerSecond); }
        fflush(logFd);
    }
    else if ( findCommand( input, "OFF\n", 0, 0) == 1 )
    {
        if( logging == 1 ) { fprintf(logFd, "%s\n", input); }
        fflush(logFd);
        offHandler();
    }
    else
    {
        fprintf(stderr, "Error: not one of the avaialble commands"); // GET ERROR HERE TOO
        exit(1);
    }
}

float recordTemperature( char tempScaleFlag )
{
    int B  = 4275;
    int R0 = 100000;

    float retTemp;

    int temp = mraa_aio_read(sensor); // reads in celsius

    float R = 1023/temp-1;

    R *= R0;

    float tempC = 1.0/(log(R/R0)/B+1/298.15)-273.15;

    if(tempScaleFlag == 'C')
    {
        retTemp = tempC;
    }
    else if( tempScaleFlag == 'F')
    {
        retTemp = tempC*1.8 + 32;
    }

    return retTemp;
}

int main(int argc, char* argv[]) {

    static struct option long_options[] = {
            {"period"   , optional_argument, NULL, PERIOD},
            {"scale"    , optional_argument, NULL, SCALE },
            {"log"      , required_argument, NULL, LOG   }
    };

    int getoptReturnChar = -1;

    char tempScale = 'F';
    int pauseWriting = 0; // not paused


    while( (getoptReturnChar = getopt_long(argc, argv, "", long_options, NULL)) != -1)
    {
        if( getoptReturnChar == PERIOD)
        {
            samplesPerSecond = atoi(optarg);
            if( samplesPerSecond <= 0 )
            {
                fprintf( stderr, "Error: incorrect period");
                exit(1);
            }
            // tempScale = should lower case also work?
        }
        else if ( getoptReturnChar == SCALE )
        {
            if( (optarg[0] != 'C' && optarg[0] != 'F') || optarg[1] != '\0' )
            {
                fprintf(stderr, "Error: not one of the specified temperature scales");
                exit(1);
            }
            tempScale = optarg[0];
        }
        else if ( getoptReturnChar == LOG )
        {
            logging = 1;
            logFd = fopen(optarg, "w"); // Double check you are writing to the right place
        }
        else
        {
            fprintf(stderr, "Not one of the specified options \n");
            exit(1);
        }
    }

    sensor = mraa_aio_init(1);
    button = mraa_gpio_init(60);
    mraa_gpio_dir(button, MRAA_GPIO_IN);

    polls[0].fd = STDIN_FILENO;
    polls[0].events = POLLIN | POLLHUP | POLLERR;

    timeZone.tz_minuteswest = 200;
//    timeZone.tz_dsttime     = DST_USA;


    do // need to generate first report before looking at input commands
    {
        char inputs[256];
        gettimeofday(&tv, &timeZone);
        double temperature = recordTemperature( tempScale );

        if(tv.tv_sec >= periodEnd )
        {

            currentTime = localtime(&(tv.tv_sec));

            char outputBuffer[256];
            sprintf(outputBuffer, "%02d:%02d:%02d %.1f\n", currentTime->tm_hour, currentTime->tm_min, currentTime->tm_sec, temperature);

            if( logging == 1)
            {
                fputs( outputBuffer, logFd);
            }

            if( pauseWriting != 1)
            {
                fputs(outputBuffer, stdout);
            }

            periodEnd = tv.tv_sec + samplesPerSecond;
        }

        if( poll(polls, 1, 0) < 0 ) // returns number of structures with nonzero revents fields
        {
            fprintf(stderr, "Error: could not poll for events on file descriptors");
            exit(1);
        }


        if( polls[0].revents & POLLIN )
        {
            fgets( inputs, 256, stdin );
            handleInput( inputs, &pauseWriting, &tempScale );
        }
        // See if any events occur i.e. inputs from stdin

        // check to see if button was pressed
        // get time of day
        // read temperature
        // create correct format
        // print it to stdout and append to logfile
        // on button press output time and SHUTDOWN
        //memset( inputs, '\0', sizeof(char) );

    }while(!mraa_gpio_read(button));

    offHandler();

    mraa_aio_close(sensor);
    mraa_gpio_close(button);
    exit(0);
}